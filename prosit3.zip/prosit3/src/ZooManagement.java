import java.util.Scanner;

public class ZooManagement {
    public static void main(String[] args) {
        Zoo myZoo = new Zoo("My Zoo", "Tunis");

        /*for (int i = 0; i < 26; i++) {
            Animal lion = new Animal("Felidae", "Lion" + i, 5, true);
            boolean added = myZoo.addAnimal(lion);
            System.out.println("Ajout de " + lion.name + " : " + added);
        }*/
      Animal lion = new Animal("Felidae", "Lion", 5, true);

        myZoo.addAnimal(lion);
        myZoo.displayAnimals();

        int index = myZoo.searchAnimal(lion);
        System.out.println("Lion trouvé à l'index : " + index);

        Animal autreLion = new Animal("Felidae", "Lion", 5, true);
        int autreIndex = myZoo.searchAnimal(autreLion);
        System.out.println("Autre lion trouvé à l'index : " + autreIndex);
        //myZoo.removeAnimal(lion);
        myZoo.displayAnimals();
        System.out.println("Le zoo est plein ? " + myZoo.isZooFull());
        Zoo zoo1 = new Zoo("Zoo A", "Tunis");
        Zoo zoo2 = new Zoo("Zoo B", "Sfax");

        zoo1.addAnimal(new Animal("Felidae", "Lion", 5, true));
        zoo1.addAnimal(new Animal("Canidae", "Loup", 3, true));

        zoo2.addAnimal(new Animal("Crocodylidae", "Crocodile", 7, false));

        Zoo plusGrandZoo = Zoo.comparerZoo(zoo1, zoo2);
        System.out.println("Le plus grand zoo est : " + plusGrandZoo.getName());



    }

}
