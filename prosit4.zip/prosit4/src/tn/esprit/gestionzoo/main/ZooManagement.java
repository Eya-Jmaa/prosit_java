package tn.esprit.gestionzoo.main;

import tn.esprit.gestionzoo.entities.Animal;
import tn.esprit.gestionzoo.entities.Zoo;
public class ZooManagement {
    public static void main(String[] args) {

      /*Zoo myZoo = new Zoo("My Zoo", "Tunis");

      for (int i = 0; i < 26; i++) {
        Animal lion = new Animal("Felidae", "Lion" + i, 5, true);
        boolean added = myZoo.addAnimal(lion);
        System.out.println("Ajout de " + lion.name + " : " + added);
      }

      System.out.println("Le zoo est plein ? " + myZoo.isZooFull());
    }*/
      Animal tiger = new Animal("Felidae", "Tigre", -3, true);
      System.out.println(tiger);

      Zoo zoo = new Zoo("", "Tunis");
      System.out.println(zoo.getName());

      Zoo myZoo = new Zoo("Esprit Zoo", "Ariana");
      Animal lion = new Animal("Felidae", "Lion", 5, true);
      myZoo.addAnimal(lion);

      System.out.println(myZoo);
    }


    }


