import java.util.Scanner;

public class ZooManagement {
    public static void main(String[] args) {
        int nbrCages = 20;
        String zooName = "my zoo";

        System.out.println(zooName + " comporte " + nbrCages + " cages.");

        Scanner scanner = new Scanner(System.in);

        System.out.print("Entrez le nom du zoo : ");
        zooName = scanner.nextLine();

        System.out.print("Entrez le nombre de cages : ");
        while (!scanner.hasNextInt()) {
            System.out.print("Veuillez entrer un nombre entier valide pour les cages : ");
            scanner.next();
        }
        nbrCages = scanner.nextInt();

        System.out.println(zooName + " comporte " + nbrCages + " cages.");

        scanner.close();

        Zoo myZoo = new Zoo("My Zoo", "Tunis", 20);
        Animal lion = new Animal("Felidae", "Lion", 5, true);

        myZoo.animals[0] = lion;

        System.out.println(myZoo);
        System.out.println(lion);
    }
}
